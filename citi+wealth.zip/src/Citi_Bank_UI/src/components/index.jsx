export {default as MainPage} from './EmployeeView/MainPage'

export {default as CustomerView} from './EmployeeView/CustomerView'
export {default as Customer} from './CustomerView/Customer'
